# Azure DevOps + AKS Demo

This repo contains sample files (pom.xml, Dockerfile, Helm chart, Terraform infra, azure-pipelines.yml, sonar-compose.yml) to follow the step-by-step guide in the canvas document.
